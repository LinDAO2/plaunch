import { mountArcade } from '/arcade-view.js'
import { bindSound, blip, burst, shake } from '/juice.js'

const GAME_KEYS = new Set(['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'a', 'd', 'w', 's', ' ', 'f'])

export const typeNames = { tap: 'TAP CHALLENGE', reaction: 'REACTION TEST', guess: 'NUMBER GUESS', dodge: 'METEOR DODGE', arcade: 'ARCADE', world: 'BLOCKS' }

export function renderHint(el, game) {
  if (!el) return
  const text = controlHint(game)
  const prefix = 'Mouse or trackpad to move · '
  el.replaceChildren()
  if (text.startsWith(prefix)) {
    const fine = document.createElement('span')
    fine.className = 'pointer-fine'
    fine.textContent = prefix
    el.append(fine, document.createTextNode(text.slice(prefix.length)))
    return
  }
  el.textContent = text
}

export function controlHint(game) {
  if (game?.type === 'world' || game?.spec?.runtime === 'world') {
    return 'Click or drag to look. WASD and space. Click breaks, right click or E places. On a phone, use the stick, drag to look, and the place and jump buttons.'
  }
  if (game?.tier === 'freeform') return 'Sandboxed canvas. The score comes back to this page. The game cannot read this page or the network.'
  if (game?.spec?.controls?.keyboard && game?.spec?.controls?.touch) {
    const pointer = game.spec.controls.scheme === 'tap' ? '' : 'Mouse or trackpad to move · '
    return `${pointer}${game.spec.controls.keyboard} · ${game.spec.controls.touch}`
  }
  if (game?.type === 'dodge') return 'Move the mouse, use the arrow keys or A/D, or tap the on-screen arrows'
  if (game?.type === 'reaction') return 'Wait for the signal, then tap. Faster is better.'
  if (game?.type === 'guess') return 'Guess a number from 1 to 10. Fewer attempts score higher.'
  return 'Tap as many times as you can before time runs out.'
}

export function createRuntime(els, hooks = {}) {
  let timer = null
  let timeout = null
  let playing = false
  let phase = ''
  let points = 0
  let remaining = 10
  let secret = 0
  let startedAt = 0
  let lastScore = null
  let dodgeFrame = null
  let arcade = null
  let obstacles = []
  let dodgeX = 50
  let dodgeTick = 0
  const dodgeKeys = new Set()
  let dodgePointer = null
  let game = { name: '', description: '', type: 'tap', duration: 10, accent: '#a88bff' }
  let playStarted = false
  let goalTimer = 0
  let prevArcade = { score: 0, lives: null }
  let attract = 0

  function showGoal() {
    if (!els.goal) return
    els.goal.textContent = game.description || ''
    els.goal.hidden = !game.description
  }

  function armGoal() {
    showGoal()
    clearTimeout(goalTimer)
    goalTimer = setTimeout(() => {
      if (els.goal) els.goal.hidden = true
    }, 3000)
  }

  function hideRound() {
    if (els.round) els.round.hidden = true
  }

  function showRound(points) {
    if (!els.round || !els.roundScore) return
    els.play.hidden = true
    const line = points === null
      ? 'No score'
      : game.type === 'reaction' ? `Score ${points} ms` : `Score ${points}`
    const near = points === null ? '' : points > 0 ? ' Close. One more run.' : ' First run is the warmup.'
    els.roundScore.textContent = line + near
    const shareText = points === null ? '' : (game.type === 'reaction' ? `Score ${points} ms` : `Score ${points}`)
    let share = els.round?.querySelector('#round-share')
    if (!share && els.round && els.roundScore) {
      share = document.createElement('p')
      share.id = 'round-share'
      share.className = 'round-share'
      els.roundScore.insertAdjacentElement('afterend', share)
    }
    if (share) share.textContent = shareText
    if (els.goal) els.goal.hidden = true
    els.round.hidden = false
  }

  function emitStart() {
    if (playStarted) return
    playStarted = true
    hooks.onPlayStarted?.(game)
  }

  function stopAttract() {
    if (attract) cancelAnimationFrame(attract)
    attract = 0
  }

  function clear() {
    clearInterval(timer)
    clearTimeout(timeout)
    stopAttract()
    cancelAnimationFrame(dodgeFrame)
    arcade?.stop()
    arcade = null
    dodgeKeys.clear()
    playing = false
    phase = ''
    points = 0
    lastScore = null
    playStarted = false
    remaining = Number(game.duration) || 10
    obstacles = []
    els.score.textContent = 'Score: 0'
    els.timer.textContent = `Time: ${remaining}s`
    els.label.textContent = 'Ready'
    els.label.hidden = false
    hideRound()
    showGoal()
    els.display.textContent = '0'
    els.play.textContent = 'Play'
    els.play.hidden = false
    els.field.replaceChildren()
    els.field.style.pointerEvents = 'none'
    if (els.guess) {
      els.guess.hidden = true
      els.guess.value = ''
    }
  }

  function paintIdle() {
    els.display.textContent = ({ tap: '0', reaction: '⚡', guess: '?', dodge: '☄' })[game.type] || '0'
    if (els.root) els.root.style.borderColor = game.accent || '#FF5A3C'
    stopAttract()
    if (!els.field || game.tier === 'freeform' || game.type === 'world') return
    const canvas = document.createElement('canvas')
    canvas.className = 'arcade-canvas'
    canvas.width = 480
    canvas.height = 320
    els.field.append(canvas)
    const ctx = canvas.getContext('2d')
    const accent = /^#[0-9a-fA-F]{6}$/.test(game.accent || '') ? game.accent : '#FFD23F'
    const started = performance.now()
    const loop = (now) => {
      if (!canvas.isConnected) return
      const t = (now - started) / 1000
      ctx.fillStyle = '#4FB3FF'
      ctx.fillRect(0, 0, 480, 176)
      ctx.fillStyle = '#CDEBFF'
      ctx.fillRect(0, 176, 480, 144)
      ctx.fillStyle = '#7BC86C'
      ctx.fillRect(0, 250, 480, 70)
      const x = 240 + Math.sin(t * 1.4) * 90
      const y = 188 + Math.sin(t * 2.2) * 8
      ctx.fillStyle = '#1B1B2F'
      ctx.beginPath()
      ctx.arc(x, y + 4, 22, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(x, y, 22, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = accent
      ctx.beginPath()
      ctx.arc(x, y, 16, 0, Math.PI * 2)
      ctx.fill()
      attract = requestAnimationFrame(loop)
    }
    attract = requestAnimationFrame(loop)
  }

  function finish(value, label, opts = {}) {
    playing = false
    phase = 'done'
    clearInterval(timer)
    clearTimeout(timeout)
    cancelAnimationFrame(dodgeFrame)
    arcade?.stop()
    arcade = null
    els.field.replaceChildren()
    els.field.style.pointerEvents = 'none'
    if (els.guess) els.guess.hidden = true
    els.display.textContent = String(value)
    els.label.textContent = label
    els.label.hidden = false
    els.play.hidden = true
    els.play.textContent = 'Play again'
    lastScore = opts.keepScore === false ? null : points
    showRound(lastScore)
    hooks.onFinish?.({ points: lastScore, mechanic: game.type, game })
  }

  function spawnInterval() {
    const rate = Number(game.spec?.spawn?.rate)
    const base = game.spec?.difficulty === 'hard' ? 450 : game.spec?.difficulty === 'easy' ? 900 : 650
    if (!Number.isFinite(rate) || rate <= 0) return base
    return Math.max(180, Math.round(base / rate))
  }

  function run() {
    const g = game
    if (g.type === 'arcade') {
      clear()
      playing = true
      els.display.textContent = ''
      els.play.hidden = true
      els.label.textContent = 'ARCADE'
      els.label.hidden = true
      prevArcade = { score: 0, lives: null }
      armGoal()
      emitStart()
      const spec = g.spec?.runtime === 'arcade' ? g.spec : null
      if (!spec) {
        finish('!', 'NO ARCADE SPEC', { keepScore: false })
        return
      }
      arcade = mountArcade(els.field, spec, {
        keys: dodgeKeys,
        onScore(snap) {
          if (snap.score > prevArcade.score) {
            burst(els.field, snap.playerX, snap.playerY ?? 80, g.accent || '#e6ff3a')
            blip('score')
          }
          if (prevArcade.lives !== null && snap.lives < prevArcade.lives) {
            shake(els.root)
            burst(els.field, snap.playerX, snap.playerY ?? 80, '#f4212e')
            blip('hurt')
          }
          prevArcade = { score: snap.score, lives: snap.lives }
          points = snap.score
          els.score.textContent = `Score: ${points}`
          const left = Math.max(0, Math.ceil(((Number(g.duration) || 20) * 1000 - snap.time) / 1000))
          els.timer.textContent = `Time: ${left}s`
        },
        onEnd(snap) {
          points = snap.score
          els.score.textContent = `Score: ${points}`
          finish(snap.won ? 'Win' : String(snap.score), snap.won ? 'YOU WIN' : 'GAME OVER')
        }
      })
      return
    }
    if (g.type === 'tap') {
      if (!playing) {
        clear()
        playing = true
        remaining = g.duration
        els.play.textContent = 'TAP!'
        els.label.textContent = 'GO GO GO'
        armGoal()
        emitStart()
        timer = setInterval(() => {
          remaining -= 1
          els.timer.textContent = `Time: ${remaining}s`
          if (remaining <= 0) finish(`${points} 🎉`, 'TIME UP')
        }, 1000)
      } else {
        points += 1
        els.score.textContent = `Score: ${points}`
        els.display.textContent = String(points)
        burst(els.field, 50, 46, g.accent || '#e6ff3a')
        blip('score')
      }
      return
    }
    if (g.type === 'reaction') {
      if (phase === 'wait') {
        clearTimeout(timeout)
        shake(els.root)
        blip('hurt')
        finish('Too early', 'TOO EARLY', { keepScore: false })
      } else if (phase === 'ready') {
        const ms = Math.max(1, Math.round(performance.now() - startedAt))
        points = ms
        els.score.textContent = `Reaction: ${ms}ms`
        burst(els.field, 50, 46, '#e6ff3a')
        blip('score')
        finish(`${ms}ms`, 'NICE REFLEX')
      } else {
        clear()
        phase = 'wait'
        els.display.textContent = '…'
        els.label.textContent = 'WAIT FOR THE SIGNAL'
        els.play.textContent = 'Wait…'
        armGoal()
        emitStart()
        timeout = setTimeout(() => {
          if (phase !== 'wait') return
          phase = 'ready'
          startedAt = performance.now()
          els.display.textContent = 'GO!'
          els.label.textContent = 'CLICK NOW'
          els.play.textContent = 'CLICK!'
          burst(els.field, 50, 46, '#e6ff3a')
          blip('go')
        }, 1500 + Math.random() * 2300)
      }
      return
    }
    if (g.type === 'guess') {
      if (phase !== 'guess') {
        clear()
        phase = 'guess'
        secret = 1 + Math.floor(Math.random() * 10)
        els.label.textContent = 'GUESS 1–10'
        els.display.textContent = '?'
        els.play.textContent = 'Enter guess'
        armGoal()
        els.timer.textContent = 'No timer'
        if (els.guess) {
          els.guess.hidden = false
          els.guess.value = ''
          els.guess.focus()
        }
        emitStart()
      } else {
        const raw = els.guess ? els.guess.value : window.prompt('Choose a number from 1 to 10')
        if (raw === null) return
        const n = Number(String(raw).trim())
        if (!Number.isInteger(n) || n < 1 || n > 10) {
          hooks.onToast?.('Enter a whole number from 1 to 10')
          return
        }
        points += 1
        els.score.textContent = `Attempts: ${points}`
        if (n === secret) {
          points = Math.max(10, 100 - points * 10)
          burst(els.field, 50, 46, '#e6ff3a')
          blip('score')
          finish('Yes', 'YOU GUESSED IT')
        } else {
          els.display.textContent = n < secret ? '↑ HIGHER' : '↓ LOWER'
          if (els.guess) els.guess.value = ''
        }
      }
      return
    }
    if (g.type === 'dodge') {
      clear()
      playing = true
      points = 0
      remaining = g.duration
      dodgeX = 50
      dodgeTick = 0
      obstacles = []
      els.display.textContent = ''
      els.play.hidden = true
      els.label.textContent = 'DODGE THE METEORS'
      armGoal()
      emitStart()
      const player = document.createElement('div')
      player.className = 'dodge-player'
      const controls = document.createElement('div')
      controls.className = 'dodge-controls'
      for (const [dir, label] of [['left', '←'], ['right', '→']]) {
        const button = document.createElement('button')
        button.type = 'button'
        button.dataset.move = dir
        button.setAttribute('aria-label', dir === 'left' ? 'Move left' : 'Move right')
        button.textContent = label
        button.addEventListener('pointerdown', (event) => {
          event.preventDefault()
          move(dir === 'left' ? -1 : 1)
        })
        controls.append(button)
      }
      els.field.replaceChildren(player, controls)
      els.field.style.pointerEvents = 'auto'
      els.field.style.background = '#12082a'
      const move = (dir) => {
        dodgeX = Math.min(94, Math.max(6, dodgeX + dir * 9))
        player.style.left = `calc(${dodgeX}% - 27px)`
      }
      dodgePointer = null
      timer = setInterval(() => {
        remaining -= 1
        els.timer.textContent = `Time: ${remaining}s`
        if (remaining <= 0) {
          els.field.style.pointerEvents = 'none'
          finish('Clear', 'YOU SURVIVED')
        }
      }, 1000)
      let prev = performance.now()
      const frame = (now) => {
        if (!playing) return
        const dt = Math.min(45, now - prev)
        prev = now
        dodgeTick += dt
        const keyLeft = dodgeKeys.has('ArrowLeft') || dodgeKeys.has('a')
        const keyRight = dodgeKeys.has('ArrowRight') || dodgeKeys.has('d')
        if (keyLeft || keyRight) dodgePointer = null
        if (keyLeft) move(-0.15 * dt)
        if (keyRight) move(0.15 * dt)
        if (dodgePointer !== null) {
          const delta = dodgePointer - dodgeX
          move(Math.sign(delta) * Math.min(Math.abs(delta), 0.12 * dt * 9) / 9)
        }
        if (dodgeTick > spawnInterval()) {
          dodgeTick = 0
          const x = 8 + Math.random() * 84
          const el = document.createElement('div')
          el.className = 'meteor'
          els.field.append(el)
          obstacles.push({ x, y: -10, el })
        }
        for (const obstacle of obstacles) {
          obstacle.y += dt * 0.055
          obstacle.el.style.left = `calc(${obstacle.x}% - 15px)`
          obstacle.el.style.top = `${obstacle.y}%`
          if (obstacle.y > 72 && obstacle.y < 87 && Math.abs(obstacle.x - dodgeX) < 8) {
            els.field.style.pointerEvents = 'none'
            shake(els.root)
            blip('hurt')
            finish(points, 'CRASHED!')
            return
          }
        }
        obstacles = obstacles.filter((obstacle) => {
          if (obstacle.y <= 105) return true
          obstacle.el.remove()
          points += 10
          els.score.textContent = `Score: ${points}`
          burst(els.field, obstacle.x, 70, g.accent || '#ff779e')
          blip('score')
          return false
        })
        dodgeFrame = requestAnimationFrame(frame)
      }
      dodgeFrame = requestAnimationFrame(frame)
    }
  }

  function onKeyDown(event) {
    const tag = document.activeElement?.tagName
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) return
    const key = event.key.length === 1 ? event.key.toLowerCase() : event.key
    if (GAME_KEYS.has(key)) {
      // Only steer while a round is running, and stop arrows and Space from
      // scrolling the page out from under the game.
      if (!playing) return
      dodgeKeys.add(key)
      event.preventDefault()
    }
  }
  function onKeyUp(event) {
    const key = event.key.length === 1 ? event.key.toLowerCase() : event.key
    dodgeKeys.delete(event.key)
    dodgeKeys.delete(key)
  }

  els.play.addEventListener('click', run)
  if (els.again) els.again.addEventListener('click', run)
  bindSound(els.sound)
  // Meteor Dodge: the mouse or trackpad steers without a button; on touch this tracks a drag.
  els.field.addEventListener('pointermove', (event) => {
    if (!playing || game.type !== 'dodge' || event.target.closest?.('button')) return
    const rect = els.field.getBoundingClientRect()
    dodgePointer = ((event.clientX - rect.left) / Math.max(rect.width, 1)) * 100
  })
  if (els.guess) {
    els.guess.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault()
        run()
      }
    })
  }
  document.addEventListener('keydown', onKeyDown)
  document.addEventListener('keyup', onKeyUp)

  return {
    setGame(next) {
      game = { duration: 10, type: 'tap', accent: '#a88bff', ...next }
      clear()
      paintIdle()
    },
    destroy() {
      clear()
      document.removeEventListener('keydown', onKeyDown)
      document.removeEventListener('keyup', onKeyUp)
    },
    getLastScore() {
      return lastScore
    }
  }
}
