const STOP = new Set(['a', 'an', 'and', 'the', 'with', 'for', 'from', 'game', 'make', 'where', 'players', 'player', 'that', 'this', 'into', 'about'])

function words(text) {
  return String(text || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).filter(Boolean)
}

function has(text, ...needles) {
  const value = String(text || '').toLowerCase()
  return needles.some((needle) => value.includes(needle))
}

function titleFromPrompt(prompt, genre) {
  const clean = words(prompt).filter((word) => !STOP.has(word)).slice(0, 4)
  if (genre === 'cozy-fishing') return 'Willowmere'
  if (genre === 'survival') return 'Ashfall Frontier'
  if (genre === 'fashion-life-sim') return 'Rooftop Atelier'
  if (genre === 'platformer') return 'Skyline Run'
  if (genre === 'racing') return 'Neon Circuit'
  return clean.length ? clean.map((word) => word[0].toUpperCase() + word.slice(1)).join(' ') : 'New Playground Game'
}

function classify(prompt) {
  if (has(prompt, 'fishing', 'fish', 'lake', 'river', 'cast a line')) return 'cozy-fishing'
  if (has(prompt, 'survival', 'crafting', 'shelter', 'scavenge', 'wilderness', 'ash storm')) return 'survival'
  if (has(prompt, 'fashion', 'dress up', 'outfit', 'makeup', 'runway', 'barbie')) return 'fashion-life-sim'
  if (has(prompt, 'race', 'racing', 'kart', 'lap', 'drift')) return 'racing'
  if (has(prompt, 'platformer', 'jump', 'platforms', 'side-scrolling')) return 'platformer'
  if (has(prompt, 'farm', 'farming', 'crops', 'garden')) return 'cozy-farming'
  if (has(prompt, 'horror', 'haunted', 'ghost')) return 'horror'
  if (has(prompt, 'puzzle', 'match', 'tiles', 'chess')) return 'puzzle'
  if (has(prompt, 'build', 'blocks', 'voxel', 'cabin', 'watchtower', 'mountain', 'canyon', 'beach')) return 'voxel-world'
  return 'arcade'
}

function cameraFor(genre) {
  if (genre === 'platformer' || genre === 'racing') return 'side-on'
  if (genre === 'fashion-life-sim') return 'third-person-and-ui'
  if (genre === 'survival') return 'first-person'
  if (genre === 'voxel-world' || genre === 'cozy-fishing' || genre === 'cozy-farming') return 'third-person-over-shoulder'
  return 'top-down-or-2d'
}

function mechanicsFor(genre, prompt) {
  const table = {
    'cozy-fishing': [
      { id: 'fishing', type: 'timing-and-reaction', description: 'Cast near a fish shadow and keep the tension meter in the safe zone.' },
      { id: 'collection', type: 'journal', description: 'Discover fish, plants, insects, and wildlife.' },
      { id: 'light-decoration', type: 'placement', description: 'Decorate a cabin or lakeside home with collected objects.' }
    ],
    survival: [
      { id: 'resource-gathering', type: 'world-interaction', description: 'Gather materials from the environment.' },
      { id: 'crafting', type: 'recipe-system', description: 'Turn materials into tools, shelter, food, and equipment.' },
      { id: 'base-building', type: 'grid-and-snap-building', description: 'Create a defensible shelter with storage and utilities.' },
      { id: 'weather-survival', type: 'dynamic-event', description: 'Prepare shelter and equipment before dangerous weather arrives.' }
    ],
    'fashion-life-sim': [
      { id: 'outfit-styling', type: 'selection-and-combination', description: 'Combine clothing, accessories, hair, and colors into an original look.' },
      { id: 'social-score', type: 'creative-rating', description: 'Receive a playful theme-based score for the finished look.' },
      { id: 'space-decoration', type: 'placement', description: 'Customize a studio, room, or party space.' }
    ],
    platformer: [
      { id: 'movement', type: 'platform-navigation', description: 'Run, jump, and avoid hazards across readable levels.' },
      { id: 'collectibles', type: 'collection', description: 'Collect items that reward exploration.' }
    ],
    racing: [
      { id: 'driving', type: 'lane-or-track-navigation', description: 'Control a vehicle through gates, turns, and hazards.' },
      { id: 'timed-laps', type: 'score-attack', description: 'Finish the course quickly and improve the best time.' }
    ],
    'voxel-world': [
      { id: 'world-building', type: 'block-placement', description: 'Place and break blocks in a shared generated world.' },
      { id: 'landmark-goal', type: 'construction-quest', description: 'Raise or complete a landmark and gather world objectives.' }
    ],
    arcade: [
      { id: 'core-challenge', type: 'short-score-round', description: `Play a focused round based on the idea: ${String(prompt || '').trim().slice(0, 100)}.` }
    ]
  }
  return table[genre] || table.arcade
}

function environmentFor(genre, prompt) {
  if (genre === 'cozy-fishing') return ['lake', 'wooden-dock', 'cabin', 'willow-tree', 'mossy-rock', 'reeds']
  if (genre === 'survival') return ['wilderness', 'resource-nodes', 'shelter', 'weather-front', 'landmark']
  if (genre === 'fashion-life-sim') return ['fashion-studio', 'rooftop-party', 'wardrobe', 'photo-backdrop', 'decorative-props']
  if (genre === 'platformer') return ['platforms', 'hazards', 'collectible-path', 'background-landmarks']
  if (genre === 'racing') return ['track', 'gates', 'start-line', 'scenery', 'finish-line']
  if (genre === 'voxel-world') return ['generated-terrain', 'vegetation', 'landmark', 'water-or-canyon']
  return ['playfield', 'interactive-objects', 'score-feedback']
}

function assetStyleFor(genre) {
  if (genre === 'survival') return 'realistic-low-poly-with-pbr-materials'
  if (genre === 'cozy-fishing' || genre === 'cozy-farming' || genre === 'voxel-world') return 'stylized-realistic'
  if (genre === 'fashion-life-sim') return 'polished-stylized-3d'
  return 'cohesive-web-game-art'
}

export function buildGameRecipe(prompt, result = {}) {
  const genre = classify(prompt)
  const title = result.game?.name || titleFromPrompt(prompt, genre)
  const type = result.game?.type || (genre === 'voxel-world' ? 'world' : genre === 'arcade' ? 'arcade' : 'arcade')
  const worldBased = ['cozy-fishing', 'cozy-farming', 'survival', 'voxel-world'].includes(genre)
  return {
    schemaVersion: '1.0',
    identity: {
      title,
      tagline: result.game?.description || `An original ${genre.replaceAll('-', ' ')} game generated from one sentence.`,
      originalityNote: 'Original names, characters, locations, visuals, UI, and story; research informs mechanics without copying protected IP.',
      targetAudience: 'Players on mobile web, desktop web, and X embeds'
    },
    genre: {
      primary: genre,
      secondary: worldBased ? ['exploration', 'collection'] : ['short-session', 'score-attack'],
      camera: cameraFor(genre),
      sessionLength: genre === 'survival' ? '15-45 minutes' : '5-15 minutes'
    },
    presentation: {
      artDirection: assetStyleFor(genre),
      visualGoal: genre === 'survival' ? 'Believable materials, atmosphere, and weather with readable gameplay' : 'Distinctive authored composition with clear interaction targets',
      lighting: genre === 'horror' ? 'dramatic low-key lighting' : 'warm readable daylight',
      animationStyle: 'responsive and expressive'
    },
    world: {
      type: worldBased ? 'small-streaming-3d-world' : 'focused-play-space',
      environment: environmentFor(genre, prompt),
      worldSize: genre === 'survival' ? 'large' : 'compact',
      seededGeneration: worldBased
    },
    player: {
      role: genre === 'cozy-fishing' ? 'young naturalist' : genre === 'survival' ? 'field engineer' : 'player avatar',
      movement: genre === 'fashion-life-sim' ? ['walk', 'interact'] : ['move', 'interact'],
      startingLocation: environmentFor(genre, prompt)[0]
    },
    mechanics: mechanicsFor(genre, prompt),
    progression: {
      structure: genre === 'survival' ? 'technology-and-exploration' : genre === 'cozy-fishing' ? 'collection-journal' : 'short-session-score-and-unlocks',
      difficulty: genre === 'cozy-fishing' ? 'relaxed' : 'moderate',
      noFailMode: genre === 'cozy-fishing' || genre === 'fashion-life-sim'
    },
    assets: {
      environment: environmentFor(genre, prompt),
      interactiveProps: genre === 'cozy-fishing' ? ['fishing-rod', 'lantern', 'journal', 'fish-basket'] : genre === 'survival' ? ['axe', 'pickaxe', 'campfire', 'storage-crate', 'generator'] : ['player-avatar', 'goal-object', 'feedback-effects'],
      assetStyle: assetStyleFor(genre),
      licensePolicy: 'original-or-permissive-license-only'
    },
    audio: {
      music: genre === 'cozy-fishing' ? 'soft acoustic ambient' : genre === 'survival' ? 'minimal atmospheric tension' : 'responsive original game music',
      soundEffects: ['interaction', 'success', 'failure', 'environmental ambience'],
      adaptiveMusic: genre === 'survival'
    },
    controls: {
      desktop: { move: 'WASD-or-arrow-keys', look: 'mouse-or-pointer', interact: 'E-or-click' },
      mobile: { move: 'virtual-stick-or-touch', look: 'drag', interact: 'tap' },
      accessibility: ['reduced motion', 'subtitles', 'clear color contrast']
    },
    social: {
      shareCard: { headline: `Play ${title}`, imageStyle: 'hero gameplay moment' },
      multiplayer: type === 'world',
      spectatorFriendly: true
    },
    performance: {
      targetPlatforms: ['mobile-web', 'desktop-web', 'X-embed'],
      qualityTiers: ['low', 'medium', 'high'],
      highQualityProps: worldBased,
      targetFrameRate: 60
    },
    safety: {
      ipMode: 'inspired-by-genre-only',
      avoid: ['existing branded characters', 'copyrighted logos', 'copied locations', 'copied storylines', 'unlicensed assets']
    }
  }
}
